/*
* IT-265 Java Programming, Summer 2016
* Instructor: Martin P. Walsh
* Student Name: Natasha Ostrander
* Homework Assignment: Chap 18, Problem 7
* Purpose of Assignment: Draws a circle where the user clicks
*
 */


package chapter18problem7;

import javax.swing.JFrame;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Graphics;

public class Chapter18Problem7 extends JFrame implements MouseListener
{
    int x;
    int y;    
    
     public void paint(Graphics g)
    {
        super.paint(g);
        g.drawOval(x, y, 6, 6);
    }
    
    public void mouseClicked(MouseEvent e)
    {
        x = e.getX();
        y = e.getY();
//        System.out.println("x:"+x+"  y:"+y);
         repaint();
    }
    public void mouseEntered(MouseEvent e) 
    {
        
    }
    public void mousePressed(MouseEvent e)
    {
        
    }
    public void MouseReleased(MouseEvent e)
    {
        
    }
    public void mouseExited(MouseEvent e)
    {
        
    }
    public Chapter18Problem7()
    {
//        super();
        setSize(600,400);
        setTitle("Mouse Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addMouseListener(this);
    }

    public static void main(String[] args) 
    {
        // Course Information
        System.out.println("IT-2650 Java Programming");
        System.out.println("Student Name: Natasha Ostrander");
        System.out.println("Homework Assignment: Chapter 18, Problem 7");
        System.out.println("________________________________");
        System.out.println("");
        
        
      Chapter18Problem7 m = new Chapter18Problem7();
      m.setVisible(true);
    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) 
{
        // TODO Implement this method
    }
}
